/* =========================================================
   JavaScript Fundamentals Project
   Parts 1–4 are clearly labeled below.
   ========================================================= */

/* ========================= Part 1 =========================
   VARIABLE DECLARATIONS & CONDITIONALS
   --------------------------------------------------------- */
// Variables (different declaration keywords)
const studentName = "Alex Kim";            // const — won't change
let scores = [78, 92, 88];                 // let — mutable array
var isDarkTheme = true;                    // var — legacy keyword

// Initial DOM population (DOM interaction #1)
document.getElementById("student-name").textContent = studentName;

// A simple conditional to set the theme early
if (isDarkTheme) {
  document.body.classList.remove("light");
} else {
  document.body.classList.add("light");
}

/* ========================= Part 2 =========================
   CUSTOM FUNCTIONS (at least 2)
   --------------------------------------------------------- */
/**
 * calculateAverage: returns average of numeric array
 * Demonstrates a loop inside a function (for...of)
 */
function calculateAverage(arr) {
  if (!Array.isArray(arr) || arr.length === 0) return 0;
  let sum = 0;
  // Loop example #1 (for...of)
  for (const n of arr) {
    sum += n;
  }
  return Math.round((sum / arr.length) * 10) / 10;
}

/**
 * renderScores: renders <li> items to the list and labels each
 * Demonstrates another loop (classic for) and DOM creation
 */
function renderScores() {
  const list = document.getElementById("score-list");
  list.innerHTML = ""; // DOM interaction #2 (clear and re-render)

  // Loop example #2 (classic for)
  for (let i = 0; i < scores.length; i++) {
    const li = document.createElement("li");           // DOM interaction #3 (create)
    const label = document.createElement("span");
    const badge = document.createElement("span");
    badge.className = "badge";

    const value = scores[i];
    label.textContent = `Score ${i + 1}: ${value}`;

    // Conditional logic for labeling
    if (value >= 85) {
      badge.textContent = "Great";
      badge.classList.add("ok");
    } else if (value >= 70) {
      badge.textContent = "Fair";
      badge.classList.add("warn");
    } else {
      badge.textContent = "Needs Work";
      badge.classList.add("bad");
    }

    li.appendChild(label);    // DOM interaction #4 (append)
    li.appendChild(badge);    // DOM interaction #5 (append)
    list.appendChild(li);
  }
}

/**
 * logLine: lightweight console that prints to the page
 */
function logLine(text) {
  const log = document.getElementById("log");
  log.textContent += (text + "\n"); // DOM interaction #6 (update text)
  log.scrollTop = log.scrollHeight;
}

/* ========================= Part 3 =========================
   MORE LOOPS (additional examples shown in actions below)
   --------------------------------------------------------- */
/**
 * addScore: validates and pushes a score, then re-renders
 * (uses array push and shows a do...while input guard)
 */
function addScore(val) {
  let n = Number(val);
  // Simple guard; show a do...while pattern once
  do {
    if (Number.isFinite(n) && n >= 0 && n <= 100) break;
    logLine("⚠️ Enter a number between 0 and 100.");
    return;
  } while (false);

  scores.push(n);
  logLine(`➕ Added score: ${n}`);
  renderScores();
}

/**
 * updateStatus: calculates average and updates status text
 * Demonstrates conditionals
 */
function updateStatus() {
  const avg = calculateAverage(scores);
  document.getElementById("average").textContent = avg.toString(); // DOM interaction #7

  const statusEl = document.getElementById("status");
  if (avg >= 85) {
    statusEl.textContent = "On Track 🎯";
    statusEl.style.color = "var(--ok)"; // DOM interaction #8 (style)
  } else if (avg >= 70) {
    statusEl.textContent = "Keep Pushing 💪";
    statusEl.style.color = "var(--warn)";
  } else {
    statusEl.textContent = "Needs Support 🤝";
    statusEl.style.color = "var(--bad)";
  }
  logLine(`📊 Average recalculated: ${avg}`);
}

/**
 * toggleTheme: flips between dark and light themes
 */
function toggleTheme() {
  isDarkTheme = !isDarkTheme;
  document.body.classList.toggle("light"); // DOM interaction #9 (class toggle)
  logLine(`🎨 Theme set to: ${isDarkTheme ? "Dark" : "Light"}`);
}

/* ========================= Part 4 =========================
   WIRE UP DOM EVENTS (event listeners are also DOM interactions)
   --------------------------------------------------------- */
// Render initial list and wire events once DOM is ready
document.addEventListener("DOMContentLoaded", () => {
  renderScores();
  updateStatus();
  logLine("✅ App ready. Try adding a score or toggling the theme.");

  // Buttons
  document.getElementById("btn-calc").addEventListener("click", updateStatus);
  document.getElementById("btn-theme").addEventListener("click", toggleTheme);
  document.getElementById("btn-load").addEventListener("click", () => {
    const sample = [65, 74, 83, 91, 99];
    // Another loop usage: Array.forEach
    sample.forEach(s => scores.push(s));
    logLine("📥 Loaded sample scores: " + sample.join(", "));
    renderScores();
    updateStatus();
  });

  // Form submit
  document.getElementById("score-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const input = document.getElementById("score-input");
    addScore(input.value);
    input.value = "";
    input.focus();
  });
});
